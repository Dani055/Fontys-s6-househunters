# Recommendations & open issues

### Frontend

#### Design
Before front-end development, we started with the design. We used Figma to create a prototype of the eventual end product. In Figma, you can find components of the desired library of the stakeholder (Argon Dashboard 2), with these components you can redesign the page or add new components if necessary.

#### UI components
Before the software development part of the frontend, we created designs using Figma with pre-built components of argon dashboard 2 made by creative Tim. We recommend using a more sophisticated front-end components solution like tailwind or MUI as it will load much better code.

The current design is mostly complete, currently all pages have been implemented. However, it could be that in some cases not all buttons or functionalities have been implemented on pages for managing users. On other pages viewing the pipelines as a developer for example, as there is also no explicit guide on setting up a chatbot has not been finished fully.

We highly recommend using Figma for the frontend designs. We have designs available for the following groups. We suggest to copy these files as soon as possible, as the figma workspace might be removed in the near future.

https://www.figma.com/design/MtRXJiNKmoxZl0COcL3BUf/User-Management-FAQ-system?node-id=0-1&t=PAACpOHLU5bXEBfa-0

#### Proposal
We propose that if the following group is to work on the frontend, first understand the current backend interactions (endpoints), create a new design which supports previously mentioned features, approve it with the stakeholder, and then work on the implementation of the design and work on absent backend features.

Since we are of a software development background, we most likely have not made the “best” design. Redesigning the website is quite likely to be a followed option and in that case, first redesign, approve with stakeholders, and then implement.

As of now the backend also does not support the feature to update data sources LLM’s, this might be one of the more essential features of the overall product, as chatbots are made to be configured.

### LLM insights

#### Frontend charts
Currently, the various charts (API traffic, Referenced documents) do not look good when a larger dataset is inserted in them. 
1. The API traffic chart starts to look very dense when a period greater than 1-2 months is selected. 
2. The referenced documents chart experiences the same issues with, where the table header on the left can fit only 25 documents and if more than 25 are rendered, the only way to see the document name is to hover over the tiny bar.

#### Backend stuff
1. Error system logs are functional, but some of them are not very helpful. The content captured, as of now is just the message (no stack trace), which is not too useful for debugging.
2. The `conversationId` of the message is just an arbitrary string that was used to group messages together for demonstrational purposes.

#### Proposal
1. Insert a large dataset of messages and referenced documents in the database using mock generated data using [mockaroo](https://www.mockaroo.com/) (or any other preferred mock data generator) and adjust the charts so that they still display in a nice manner when a bigger dataset is given.
2. Find a way to include the error stack trace in the error logs (not just the error message).
3. It might be a good idea to discuss with the stakeholders how the `conversationId` should be obtained exactly. It might be worth considering creating a new model called `Conversation` that is created once the first message is sent to a chatbot, and following messages can reference the created `Conversation.id`

### User management

#### Authentication to user management

The linking of the user to the organisation is still done through an invite. However when a user logs in and is awaiting approval, the user cannot be added to an organisation yet. The question is also what person should approve this user, since the user is not connected to an organisation. Moreover, the JWT is invalidated after 1 hour, but a warning isn't given. When the user switches organisation, they should be given a new JWT token and their current one should be invalidated, so it cannot be used for malicious purposes. The same thing should happen whenever a user updates their role. The JWT is currently not valited in the frontend, so if it gets altered and used to see a page the user is not allowed to see, they can still view the page. The backend does validate the JWT, so the user doesn't get to see any data they shouldn't see. Lastly when a user logs out of the application, their JWT should also be invalidated.

#### Proposal
There should be a super admin of the system. This person should be able to set the admin of an organisation. Moreover a solution should be found for 'orphaned' users. These are users that sign in and are being created, but don't belong to an organisation yet. These could be linked to an organisation by the super admin or another solution could be investigated. The frontend should display a warning before the JWT is invalidated after 1 hour. The user should also be logged out and the JWT should be invalidated. Moreover, the JWT should be updated when a user switches organisation, so the roles and permissions are also updated. Again, the JWT should be recreated and the old JWT should be invalidated. Finally, the JWT could be validated in the frontend for improved role based access. In the frontend there is currently very little to none messaging, so when a action is performed with the backend there is no user feedback. 

### Data source management
After setting up your chatbot and pipeline it is possible to select multiple data sources. Our project faces the issue that the data source's integrity may alter over time due to deletion, modification, or additions of data and our application does not keep track of these changes as it only recieves them once the connection is made. The idea was to create a mechanism that fetches the data over a course of time. Some datasources might have a available webhook to call to check if there is a change or perhaps a function inside the app needs to be made to check for any changes in the data source, but this would be a quite expensive and what we forsee a nonscalable solution.








