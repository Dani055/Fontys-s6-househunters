# How to add Users in Azure

Note: this is only required when you want to create a test user. Once this user logs in, the user is created within our application.
The Azure roles can be added, but don't have to be since the creation of roles is done in our application and independent of Azure. They Azure roles won't be used.

### Adding new users to Azure Entra ID

Navigate to Azure Entra ID.
![Alt text](assets/0.png)

Add user role.
![Alt text](assets/1.png)

### Adding roles

To add roles go to Enterprise applications.
![Alt text](assets/2.png)

Then go to Authentication.
![Alt text](assets/3.png)

Then Users and groups and add a user.
![Alt text](assets/4.png)

Then assign a role to the user and click Assign.
![Alt text](assets/5.png)

### Adding user to an organization
Note: As we currently do not have user organization management, we need to add the user's organisation in the database within the `UsersInOrganisation` table.

![Alt text](assets/6.png)

The `userID` is a UUID and the `sub` value from the Azure idToken is set under the `identifier` in the `ExternalIdentity` table.
![Alt text](assets/7.png)
