## Hi there 👋

We have created several documents to help you understand the application that we have made and to help you get started quickly. We assume you already have had some contact with _Stefan_ and or _Koen_ and know the general idea of the FAQ management platform.

- [Application architecture](Architecture.md)
- [Frontend explanation](front-end.md)
- [Backend explanation](back-end.md)
- [How to Deploy](Deployment.md)
- [How to add users in Azure](Adding-user-Azure.md)
- [Recommendations & Open issues](Recommendations-and-open-issues.md)

