The dashboard is a combination of the graphs that can be seen in the api traffic, referenced documents and user feedback pages. Moreover, it has a few more useful indicators that can be seen at a glance. The overview can be adjusted per organization and timespan.

![img](../assets/dashboard.png)