# Referenced documents
The user feedback dashboard displays what documents get referenced in a specific pipeline (or all pipelines in an organization) when the chat bot answers a question.

![img](../assets/referenced-document-1.png)
