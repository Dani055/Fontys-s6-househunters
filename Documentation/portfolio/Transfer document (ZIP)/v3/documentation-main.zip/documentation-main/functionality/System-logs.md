# System logs

System logs are meant for administrators of CY2 to keep track of the system. They can only be accessed by users with the 'System admin' role. 

- Info logs are meant for debugging or logging informational events.
- Warning logs are linked to bad requests, failed login attempts, sensitive actions (like token creation/deletion) and 4xx requests from the server.
- Error logs are meant for capturing runtime exceptions that happen in the backend and anything that results in a 5xx response code so they can be investigated.

![img](../assets/logs-1.png)

On the right side of the screen is a filter box that can be used for searching through the logs based on content, timestamp, etc.

Logs can be further expanded by clicking on a table entry.
![img](../assets/logs-2.png)

Logs can also be deleted by using the checkboxes on the side and pressing the 'delete' button.
