# Roles and permissions

An administrator is be able to create roles for his organization. 

The permissions are defined globally globally for the system, however roles are attached to a certain organization. 

This way, an organisation using the system can define their own roles and assign the permissions needed for their roles. A user can be assigned to multiple roles when needed.

![img](../assets/role-overview.png)