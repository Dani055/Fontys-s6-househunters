# Invites

An admin can invite new users. The admin needs to fill in the user details.

![img](../assets/invite.png)

The admin can then send the URL of the application to the user. Once the user logs in, the system will link the user to the details entered in the invite. The user doesn't have to be approved by the admin anymore, the account is immediately approved (```hasAccess```).