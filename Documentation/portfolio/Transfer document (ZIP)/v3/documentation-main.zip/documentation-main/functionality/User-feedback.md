# User feedback

The user feedback dashboard displays user feedback linked to a specific pipeline in an organization can be seen to give a better insight into how the pipeline is performing.

![img](../assets/user-feedback-1.png)

On the right side of the screen is a filter box that can be used for searching through the feedback based on the rating, pipeline, etc.

The feedback can be further expanded by clicking on a table entry.
![img](../assets/user-feedback-2.png)

The conversation that the feedback is a part of can be seen by clicking the "view conversation" button

![img](../assets/conversation.png)