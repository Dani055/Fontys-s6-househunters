# API traffic

The api traffic page showcases the amount of messages exchanged with a specific pipeline in an organization (or all pipelines). The Statiscis does not account for normal requests to the backend, but only a full forwards-and-back message and answer from the pipeline.

![img](../assets/api-traffic-1.png)
