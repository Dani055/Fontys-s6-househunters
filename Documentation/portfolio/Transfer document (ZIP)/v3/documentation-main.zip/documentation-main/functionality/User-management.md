# User management

A user is able to login using Azure and will be automatically added to the database. We retrieve the sub (unique identifier, userID) of the user from the JWT token from Azure and save this in the ExternalIdentity table in the database. This way the system is built for possible expansion so that a user can login with multiple IDP’s. 

In the user overview, an admin can see the approved users in his organisation:

![img](../assets/user-overview.png)

The number besides the hourglass icon indicates the amount users waiting for approval. These can be seen in the pending overview (at the hourglass):

![img](../assets/pending-overview.png)

Multiple users can be accepted or rejected at the same time.

If a user is rejected, the user will be deleted, since there is no point in storing the data anymore.

A user can also be edited. The user details can be updated or roles can be added/removed. Moreover, the user can be deactivated and activated, as well as being completely deleted.

![img](../assets/edit-user.png)

A video which explains all user management related functionalities can be found [here](https://github.com/CY2Project/documentation/blob/main/videos/user-management-explanation.mp4).